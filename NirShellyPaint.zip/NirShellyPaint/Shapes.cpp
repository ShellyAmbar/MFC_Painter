#include "stdafx.h"
#include "Shapes.h"

Shapes::Shapes(void)
{
}

Shapes::~Shapes(void)
{
}

MyRectangle::MyRectangle(){}

MyEllipse::MyEllipse(){}

MyTriangle::MyTriangle(){}

MyLine::MyLine(){}

MyPen::MyPen(){}

